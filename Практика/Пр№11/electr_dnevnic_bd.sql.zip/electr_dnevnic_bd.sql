-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 01 2020 г., 22:01
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `electr_dnevnic.bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `1dz`
--

CREATE TABLE `1dz` (
  `Russian` varchar(1000) NOT NULL,
  `Mathematics` varchar(1000) NOT NULL,
  `Literature` varchar(1000) NOT NULL,
  `History` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `2 dz`
--

CREATE TABLE `2 dz` (
  `English` varchar(1000) NOT NULL,
  `Physical Culture` varchar(1000) NOT NULL,
  `Music` varchar(1000) NOT NULL,
  `Technology` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `3 dz`
--

CREATE TABLE `3 dz` (
  `Chemistry` varchar(1000) NOT NULL,
  `Biology` varchar(1000) NOT NULL,
  `Physics` varchar(1000) NOT NULL,
  `Ecology` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `4 dz`
--

CREATE TABLE `4 dz` (
  `Geography` varchar(1000) NOT NULL,
  `Natural science` varchar(1000) NOT NULL,
  `Astronomy` varchar(1000) NOT NULL,
  `Surrounding world` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `5 dz`
--

CREATE TABLE `5 dz` (
  `ART` varchar(1000) NOT NULL,
  `Algebra` varchar(1000) NOT NULL,
  `Geometry` varchar(1000) NOT NULL,
  `Computer science` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `6 dz`
--

CREATE TABLE `6 dz` (
  `Life safety` varchar(1000) NOT NULL,
  `World art culture` varchar(1000) NOT NULL,
  `Philosophy` varchar(1000) NOT NULL,
  `Drawing` varchar(1000) NOT NULL,
  `Local lore` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `admin`
--

CREATE TABLE `admin` (
  `id` int(11) UNSIGNED NOT NULL,
  `Login` varchar(100) NOT NULL,
  `Email` varchar(90) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `School` varchar(120) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `calendar`
--

CREATE TABLE `calendar` (
  `Monday` int(10) DEFAULT NULL,
  `Tuesday` int(10) DEFAULT NULL,
  `Wednesday` int(10) DEFAULT NULL,
  `Thursday` int(10) DEFAULT NULL,
  `Friday` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `family`
--

CREATE TABLE `family` (
  `Parents` varchar(1000) NOT NULL,
  `Child` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `kolichestvo yrokov`
--

CREATE TABLE `kolichestvo yrokov` (
  `Russian` int(255) NOT NULL,
  `Mathematics` int(255) NOT NULL,
  `Literature` int(255) NOT NULL,
  `History` int(255) NOT NULL,
  `English` int(255) NOT NULL,
  `Physical Culture` int(255) DEFAULT NULL,
  `Music` int(255) DEFAULT NULL,
  `Technology` int(255) DEFAULT NULL,
  `Chemistry` int(255) DEFAULT NULL,
  `Biology` int(255) DEFAULT NULL,
  `Physics` int(255) DEFAULT NULL,
  `Ecology` int(255) DEFAULT NULL,
  `Geography` int(255) DEFAULT NULL,
  `Natural science` int(255) DEFAULT NULL,
  `Astronomy` int(255) DEFAULT NULL,
  `Surrounding world` int(255) DEFAULT NULL,
  `ART` int(255) DEFAULT NULL,
  `Algebra` int(255) DEFAULT NULL,
  `Geometry` int(255) DEFAULT NULL,
  `Computer science` int(255) DEFAULT NULL,
  `Life safety` int(255) DEFAULT NULL,
  `World art culture` int(255) DEFAULT NULL,
  `Philosophy` int(255) DEFAULT NULL,
  `Drawing` int(255) DEFAULT NULL,
  `Local lore` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `ochenki`
--

CREATE TABLE `ochenki` (
  `Russian` int(255) NOT NULL,
  `Mathematics` int(255) NOT NULL,
  `Literature` int(255) NOT NULL,
  `History` int(255) NOT NULL,
  `English` int(255) NOT NULL,
  `Physical Culture` int(255) DEFAULT NULL,
  `Music` int(255) DEFAULT NULL,
  `Technology` int(255) DEFAULT NULL,
  `Chemistry` int(255) DEFAULT NULL,
  `Biology` int(255) DEFAULT NULL,
  `Physics` int(255) DEFAULT NULL,
  `Ecology` int(255) DEFAULT NULL,
  `Geography` int(255) DEFAULT NULL,
  `Natural science` int(255) DEFAULT NULL,
  `Astronomy` int(255) DEFAULT NULL,
  `Surrounding world` int(255) DEFAULT NULL,
  `ART` int(255) DEFAULT NULL,
  `Algebra` int(255) DEFAULT NULL,
  `Geometry` int(255) DEFAULT NULL,
  `Computer science` int(255) DEFAULT NULL,
  `Life safety` int(255) DEFAULT NULL,
  `World art culture` int(255) DEFAULT NULL,
  `Philosophy` int(255) DEFAULT NULL,
  `Drawing` int(255) DEFAULT NULL,
  `Local lore` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `organizations`
--

CREATE TABLE `organizations` (
  `School` varchar(1000) NOT NULL,
  `Area` varchar(1000) NOT NULL,
  `Number of students` int(255) NOT NULL,
  `Director of the organization` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `school`
--

CREATE TABLE `school` (
  `Class` varchar(5) NOT NULL,
  `School` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) UNSIGNED NOT NULL,
  `Name` varchar(70) NOT NULL,
  `FName` varchar(70) NOT NULL,
  `OName` varchar(70) DEFAULT NULL,
  `Login` varchar(100) NOT NULL,
  `Email` varchar(90) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Class` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `yroki`
--

CREATE TABLE `yroki` (
  `Russian` int(255) NOT NULL,
  `Mathematics` int(255) NOT NULL,
  `Literature` int(255) NOT NULL,
  `History` int(255) NOT NULL,
  `English` int(255) NOT NULL,
  `Physical Culture` int(255) DEFAULT NULL,
  `Music` int(255) DEFAULT NULL,
  `Technology` int(255) DEFAULT NULL,
  `Chemistry` int(255) DEFAULT NULL,
  `Biology` int(255) DEFAULT NULL,
  `Physics` int(255) DEFAULT NULL,
  `Ecology` int(255) DEFAULT NULL,
  `Geography` int(255) DEFAULT NULL,
  `Natural science` int(255) DEFAULT NULL,
  `Astronomy` int(255) DEFAULT NULL,
  `Surrounding world` int(255) DEFAULT NULL,
  `ART` int(255) DEFAULT NULL,
  `Algebra` int(255) DEFAULT NULL,
  `Geometry` int(255) DEFAULT NULL,
  `Computer science` int(255) DEFAULT NULL,
  `Life safety` int(255) DEFAULT NULL,
  `World art culture` int(255) DEFAULT NULL,
  `Philosophy` int(255) DEFAULT NULL,
  `Drawing` int(255) DEFAULT NULL,
  `Local lore` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `zz` (`Email`,`Login`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `Dlia individualnisti` (`Login`,`Email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
