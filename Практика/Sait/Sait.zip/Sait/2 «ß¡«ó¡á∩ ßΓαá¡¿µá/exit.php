<?php  setcookie('user', $user['name'], time() - 3600, "/");

header('Location:http://sait/Glavnai%20stranica.php');

?>